package com.frame.presentation.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

import com.frame.business.service.RecruitersService;
import com.frame.presentation.form.RecruiterForm;

/**
*
* @author Yuzana Zaw Zaw
*/
public class RecruiterLoginAction extends BaseAction {
	private RecruitersService myRecruitersService;
	
	public RecruitersService getMyRecruitersService() {
		return myRecruitersService;
	}

	public void setMyRecruitersService(RecruitersService myRecruitersService) {
		this.myRecruitersService = myRecruitersService;
	}

	protected String doExecute(ActionForm form, HttpServletRequest request,
			HttpServletResponse response, ActionMapping mapping)
			throws Exception {
		// TODO Auto-generated method stub
	   RecruiterForm myForm=(RecruiterForm)form;
	   //checking login user
	   myRecruitersService.checkLoginUser(myForm);
	   ActionErrors errors=new ActionErrors();
	   if(myForm.getFrmLoginEmail().equals("")){		
		   errors.add("loginerror", new ActionMessage("errors.login.email.required"));
		   saveErrors(request,errors);
		   return "gotoLogin";
	   }
	   if(myForm.getFrmLoginPassword().equals("")){		
		   errors.add("loginerror", new ActionMessage("errors.login.password.required"));
		   saveErrors(request,errors);
		   return "gotoLogin";
	   }
	   if(myForm.getLoginUser()==null)
	   { 
		   errors.add("loginerror", new ActionMessage("errors.login"));
		   saveErrors(request,errors);
		   return "gotoLogin";
	   }else if(myForm.getLoginUser().getStatus().getDescription().equals("INACTIVE")){
		   errors.add("loginerror", new ActionMessage("errors.login.inactive"));
		   saveErrors(request,errors);
		   return "gotoLogin";
	   }
	   else
	   {
		   request.getSession(true);
		   request.getSession().setAttribute("id", request.getSession().getId());
		   return "gotoRecModule";
	   }
		
	}


}
