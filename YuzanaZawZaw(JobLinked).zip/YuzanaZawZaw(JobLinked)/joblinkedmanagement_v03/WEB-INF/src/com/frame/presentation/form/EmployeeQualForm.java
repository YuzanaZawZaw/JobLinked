package com.frame.presentation.form;
import java.util.List;

import org.apache.struts.validator.ValidatorForm;

import com.frame.business.entity.EmployeeQual;
import com.frame.business.entity.QualType;

/**
*
* @author Yuzana Zaw Zaw
*/
public class EmployeeQualForm extends ValidatorForm {

	//for Employee profile details
	private EmployeeQual frmDetailEmpQual;
	private List<QualType> frmQualTypeList;
	public List<QualType> getFrmQualTypeList() {
		return frmQualTypeList;
	}

	public void setFrmQualTypeList(List<QualType> frmQualTypeList) {
		this.frmQualTypeList = frmQualTypeList;
	}

	public EmployeeQual getFrmDetailEmpQual() {
		return frmDetailEmpQual;
	}

	public void setFrmDetailEmpQual(EmployeeQual frmDetailEmpQual) {
		this.frmDetailEmpQual = frmDetailEmpQual;
	}

	public List<EmployeeQual> getFrmDetailEmpQualList() {
		return frmDetailEmpQualList;
	}

	public void setFrmDetailEmpQualList(List<EmployeeQual> frmDetailEmpQualList) {
		this.frmDetailEmpQualList = frmDetailEmpQualList;
	}

	public String getFrmDetailEmpQualId() {
		return frmDetailEmpQualId;
	}

	public void setFrmDetailEmpQualId(String frmDetailEmpQualId) {
		this.frmDetailEmpQualId = frmDetailEmpQualId;
	}

	public String getFrmControl() {
		return frmControl;
	}

	public void setFrmControl(String frmControl) {
		this.frmControl = frmControl;
	}

	private List<EmployeeQual> frmDetailEmpQualList;
	private String frmDetailEmpQualId;
	private String frmControl;
	
	//for adding employee qualification
	private String frmQualTypeName;
	public String getFrmQualTypeName() {
		return frmQualTypeName;
	}

	public void setFrmQualTypeName(String frmQualTypeName) {
		this.frmQualTypeName = frmQualTypeName;
	}

	public String getFrmSchoolName() {
		return frmSchoolName;
	}

	public void setFrmSchoolName(String frmSchoolName) {
		this.frmSchoolName = frmSchoolName;
	}

	public String getFrmDegree() {
		return frmDegree;
	}

	public void setFrmDegree(String frmDegree) {
		this.frmDegree = frmDegree;
	}

	public String getFrmFieldOfStudy() {
		return frmFieldOfStudy;
	}

	public void setFrmFieldOfStudy(String frmFieldOfStudy) {
		this.frmFieldOfStudy = frmFieldOfStudy;
	}

	public String getFrmFieldOfActivity() {
		return frmFieldOfActivity;
	}

	public void setFrmFieldOfActivity(String frmFieldOfActivity) {
		this.frmFieldOfActivity = frmFieldOfActivity;
	}

	private String frmSchoolName;
	private String frmDegree;
	private String frmFieldOfStudy;
	private String frmFieldOfActivity;
	private String frmFromDate;
	public String getFrmFromDate() {
		return frmFromDate;
	}

	public void setFrmFromDate(String frmFromDate) {
		this.frmFromDate = frmFromDate;
	}

	public String getFrmThruDate() {
		return frmThruDate;
	}

	public void setFrmThruDate(String frmThruDate) {
		this.frmThruDate = frmThruDate;
	}

	private String frmThruDate;
	
	//for delete employee skill
	private int frmEmployeeId;
	private int frmQualTypeId;
	public int getFrmEmployeeId() {
		return frmEmployeeId;
	}

	public void setFrmEmployeeId(int frmEmployeeId) {
		this.frmEmployeeId = frmEmployeeId;
	}

	public int getFrmQualTypeId() {
		return frmQualTypeId;
	}

	public void setFrmQualTypeId(int frmQualTypeId) {
		this.frmQualTypeId = frmQualTypeId;
	}
	
}
