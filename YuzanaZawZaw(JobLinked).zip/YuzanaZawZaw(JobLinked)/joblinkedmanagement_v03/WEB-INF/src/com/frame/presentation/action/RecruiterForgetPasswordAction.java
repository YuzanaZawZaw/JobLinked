package com.frame.presentation.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

import com.frame.business.service.RecruitersService;
import com.frame.presentation.form.RecruiterForm;

/**
*
* @author Yuzana Zaw Zaw
*/
public class RecruiterForgetPasswordAction extends BaseAction {
	private RecruitersService myRecruitersService;
	
	public RecruitersService getMyRecruitersService() {
		return myRecruitersService;
	}

	public void setMyRecruitersService(RecruitersService myRecruitersService) {
		this.myRecruitersService = myRecruitersService;
	}

	protected String doExecute(ActionForm form, HttpServletRequest request,
			HttpServletResponse response, ActionMapping mapping)
			throws Exception {
		// TODO Auto-generated method stub
	   RecruiterForm myForm=(RecruiterForm)form;
	   //checking security question
	   myRecruitersService.verifySecurityQuestion(myForm);
	   ActionErrors errors=new ActionErrors();
	   if(myForm.getLoginUser()==null)
	   { 
		   errors.add("forgetPassError", new ActionMessage("errors.forget.password"));
		   saveErrors(request,errors);
		   return "gotoForgetPass";
	   }
	   else
	   {
		   request.getSession(true);
		   request.getSession().setAttribute("id", request.getSession().getId());		   
		   return "gotoRecruiterModule";
	   }
		
	}


}
