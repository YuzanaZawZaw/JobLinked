package com.frame.presentation.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import com.frame.business.service.EmployeeExpService;
import com.frame.presentation.form.EmployeeExpForm;
import com.frame.presentation.form.EmployeeForm;

/**
*
* @author Yuzana Zaw Zaw
*/
public class EmployeeExpAction extends BaseAction {
	private EmployeeExpService myEmployeeExpService;

	
	public EmployeeExpService getMyEmployeeExpService() {
		return myEmployeeExpService;
	}

	public void setMyEmployeeExpService(EmployeeExpService myEmployeeExpService) {
		this.myEmployeeExpService = myEmployeeExpService;
	}

	protected String doExecute(ActionForm form, HttpServletRequest request,
			HttpServletResponse response, ActionMapping mapping)
			throws Exception {
		EmployeeExpForm myForm = (EmployeeExpForm) form;
		EmployeeForm loginForm = (EmployeeForm) request.getSession()
		.getAttribute("EmpLoginFormBean");
		myEmployeeExpService.createEmployeePositionFulfillment(myForm,loginForm);
		myEmployeeExpService.firstLoadEmployeeExpDisplayTag(myForm, loginForm.getLoginUser());
		return "gotoEmpExp";
	}

	@Override
	protected String doInit(ActionForm form, HttpServletRequest request,
			HttpServletResponse response, ActionMapping mapping) {
		EmployeeExpForm myForm = (EmployeeExpForm) form;
		HttpSession session = request.getSession(false);
		if (session.getAttribute("id") == null) {
			return "gotoLogin";
		}
		EmployeeForm loginForm = (EmployeeForm) request.getSession()
		.getAttribute("EmpLoginFormBean");
			
		myEmployeeExpService.firstLoadEmployeeExpDisplayTag(myForm,loginForm.getLoginUser());
		myEmployeeExpService.firstLoadPosition(myForm);
		return "gotoEmpExp";
	}

}
