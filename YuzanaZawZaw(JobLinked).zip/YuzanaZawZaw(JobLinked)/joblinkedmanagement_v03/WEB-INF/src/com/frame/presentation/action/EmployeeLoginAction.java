package com.frame.presentation.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

import com.frame.business.service.EmployeeService;
import com.frame.presentation.form.EmployeeForm;

/**
*
* @author Yuzana Zaw Zaw
*/
public class EmployeeLoginAction extends BaseAction {
	private EmployeeService myEmployeeService;
	

	public EmployeeService getMyEmployeeService() {
		return myEmployeeService;
	}


	public void setMyEmployeeService(EmployeeService myEmployeeService) {
		this.myEmployeeService = myEmployeeService;
	}


	protected String doExecute(ActionForm form, HttpServletRequest request,
			HttpServletResponse response, ActionMapping mapping)
			throws Exception {
		// TODO Auto-generated method stub
	   EmployeeForm myForm=(EmployeeForm)form;
	   myEmployeeService.checkLoginUser(myForm);
	   ActionErrors errors=new ActionErrors();
	   if(myForm.getFrmLoginEmail().equals("")){		
		   errors.add("loginerror", new ActionMessage("errors.login.email.required"));
		   saveErrors(request,errors);
		   return "gotoLogin";
	   }
	   if(myForm.getFrmLoginPassword().equals("")){		
		   errors.add("loginerror", new ActionMessage("errors.login.password.required"));
		   saveErrors(request,errors);
		   return "gotoLogin";
	   }
	   if(myForm.getLoginUser()==null)
	   { 
		   errors.add("loginerror", new ActionMessage("errors.login"));
		   saveErrors(request,errors);
		   return "gotoLogin";
	   }else if(myForm.getLoginUser().getStatus().getDescription().equals("INACTIVE")){
		   errors.add("loginerror", new ActionMessage("errors.login.inactive"));
		   saveErrors(request,errors);
		   return "gotoLogin";
	   }
	   else
	   {
		   request.getSession(true);
		   request.getSession().setAttribute("id", request.getSession().getId());
		   return "gotoEmplModule";
	   }
		
	}


}
