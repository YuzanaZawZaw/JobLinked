package com.frame.presentation.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import com.frame.business.service.AdminService;
import com.frame.presentation.form.AdminForm;
/**
*
* @author Yuzana Zaw Zaw
*/
public class AdminChangePasswordAction extends BaseAction {
	private AdminService myAdminService;

	public AdminService getMyAdminService() {
		return myAdminService;
	}

	public void setMyAdminService(AdminService myAdminService) {
		this.myAdminService = myAdminService;
	}

	protected String doExecute(ActionForm form, HttpServletRequest request,
			HttpServletResponse response, ActionMapping mapping)
			throws Exception {
		// TODO Auto-generated method stub
		//using AdminForm
		AdminForm myForm = (AdminForm) form;
		ActionErrors errors = new ActionErrors();
		//getting session
		HttpSession session = request.getSession(false);
		if (session.getAttribute("id") == null) {
			return "gotoLogin";
		}
		//getting Login User form bean
		AdminForm loginForm = (AdminForm) request.getSession().getAttribute(
				"AdminLoginFormBean");
		myForm.setLoginUser(loginForm.getLoginUser());
		//checking login user
		boolean loginUserFlag = myAdminService.checkLoginUser(loginForm
				.getLoginUser().getEmail(), myForm.getFrmChangeOldPassword());
		//checking old password and new password
		if (myForm.getFrmChangeOldPassword().equals("")) {
			errors.add("passwordError", new ActionMessage("errors.oldPassword"));
			saveErrors(request, errors);
			return "gotoAdminChangePass";
		}
		if (myForm.getFrmChangeNewPassword().equals("")) {
			errors.add("passwordError", new ActionMessage("errors.newPassword"));
			saveErrors(request, errors);
			return "gotoAdminChangePass";
		}
		if (myForm.getFrmChangeConfirmPassword().equals("")) {
			errors.add("passwordError", new ActionMessage(
					"errors.confirmPassword"));
			saveErrors(request, errors);
			return "gotoAdminChangePass";
		}
		//checking password and saving changes
		if (loginUserFlag == true) {
			if (myForm.getFrmChangeNewPassword().equals(
					myForm.getFrmChangeConfirmPassword())
					&& !myForm.getFrmChangeNewPassword().equals("")
					&& !myForm.getFrmChangeConfirmPassword().equals("")) {
				myAdminService.saveUpdateAdmin(myForm);
				return "gotoAdminModule";
			} else {
				errors.add("passwordError", new ActionMessage(
						"errors.matchPassword"));
				saveErrors(request, errors);
				return "gotoAdminChangePass";
			}
		} else {
			errors.add("passwordError", new ActionMessage(
					"err.user.old.password.invalid"));
			saveErrors(request, errors);
			return "gotoAdminChangePass";
		}
	}

}
