package com.frame.presentation.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import com.frame.business.service.AdminService;
import com.frame.presentation.form.AdminForm;

/**
 * 
 * @author Yuzana Zaw Zaw
 */
public class AdminLoginAction extends BaseAction {
	private AdminService myAdminService;

	public AdminService getMyAdminService() {
		return myAdminService;
	}

	public void setMyAdminService(AdminService myAdminService) {
		this.myAdminService = myAdminService;
	}

	protected String doExecute(ActionForm form, HttpServletRequest request,
			HttpServletResponse response, ActionMapping mapping)
			throws Exception {
		// TODO Auto-generated method stub
		//using AdminForm 
		AdminForm myForm = (AdminForm) form;
		ActionErrors errors = new ActionErrors();
		if (myForm.getFrmLoginEmail().equals("")) {
			errors.add("loginerror", new ActionMessage(
					"errors.login.email.required"));
			saveErrors(request, errors);
			return "gotoLogin";
		}
		if (myForm.getFrmLoginPassword().equals("")) {
			errors.add("loginerror", new ActionMessage(
					"errors.login.password.required"));
			saveErrors(request, errors);
			return "gotoLogin";
		}
		//checking Login User
		myAdminService.checkLoginUser(myForm);
		if (myForm.getLoginUser() == null) {
			errors.add("loginerror", new ActionMessage("errors.login"));
			saveErrors(request, errors);
			return "gotoLogin";
		} else {
			request.getSession(true);
			request.getSession().setAttribute("id",
					request.getSession().getId());
			return "gotoAdminModule";
		}
	}

}
