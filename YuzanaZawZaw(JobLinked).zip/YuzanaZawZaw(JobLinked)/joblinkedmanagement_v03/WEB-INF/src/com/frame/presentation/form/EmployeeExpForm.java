package com.frame.presentation.form;
import java.util.List;
import org.apache.struts.validator.ValidatorForm;
import com.frame.business.entity.EmployeePositionFulfillment;
import com.frame.business.entity.PartyGroupPosition;

/**
*
* @author Yuzana Zaw Zaw
*/
public class EmployeeExpForm extends ValidatorForm {

	//for Employee profile details
	private List<EmployeePositionFulfillment> frmDetailEmpPositionList;

	public List<EmployeePositionFulfillment> getFrmDetailEmpPositionList() {
		return frmDetailEmpPositionList;
	}

	public void setFrmDetailEmpPositionList(
			List<EmployeePositionFulfillment> frmDetailEmpPositionList) {
		this.frmDetailEmpPositionList = frmDetailEmpPositionList;
	}
	
	//for create employee experiences
	private String frmPositionName;
	private List<PartyGroupPosition> frmPositionList;
	public List<PartyGroupPosition> getFrmPositionList() {
		return frmPositionList;
	}

	public void setFrmPositionList(List<PartyGroupPosition> frmPositionList) {
		this.frmPositionList = frmPositionList;
	}

	public String getFrmPositionName() {
		return frmPositionName;
	}

	public void setFrmPositionName(String frmPositionName) {
		this.frmPositionName = frmPositionName;
	}

	public String getFrmEmploymentType() {
		return frmEmploymentType;
	}

	public void setFrmEmploymentType(String frmEmploymentType) {
		this.frmEmploymentType = frmEmploymentType;
	}

	public String getFrmLocation() {
		return frmLocation;
	}

	public void setFrmLocation(String frmLocation) {
		this.frmLocation = frmLocation;
	}

	public String getFrmCurrentRole() {
		return frmCurrentRole;
	}

	public void setFrmCurrentRole(String frmCurrentRole) {
		this.frmCurrentRole = frmCurrentRole;
	}

	public String getFrmFromDate() {
		return frmFromDate;
	}

	public void setFrmFromDate(String frmFromDate) {
		this.frmFromDate = frmFromDate;
	}

	public String getFrmThruDate() {
		return frmThruDate;
	}

	public void setFrmThruDate(String frmThruDate) {
		this.frmThruDate = frmThruDate;
	}

	private String frmEmploymentType;
	private String frmLocation;
	private String frmCurrentRole;
	private String frmFromDate;
	private String frmThruDate;
	
	//for delete employee positions
	private String frmEmployeeId;
	public String getFrmEmployeeId() {
		return frmEmployeeId;
	}

	public void setFrmEmployeeId(String frmEmployeeId) {
		this.frmEmployeeId = frmEmployeeId;
	}

	public String getFrmPositionId() {
		return frmPositionId;
	}

	public void setFrmPositionId(String frmPositionId) {
		this.frmPositionId = frmPositionId;
	}

	private String frmPositionId;
	
}
