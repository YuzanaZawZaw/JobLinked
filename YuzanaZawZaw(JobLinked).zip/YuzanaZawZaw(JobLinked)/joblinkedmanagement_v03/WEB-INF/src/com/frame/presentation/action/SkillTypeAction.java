package com.frame.presentation.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import com.frame.business.service.SkillTypeService;
import com.frame.presentation.form.SkillTypeForm;

/**
*
* @author Yuzana Zaw Zaw
*/
public class SkillTypeAction extends BaseAction {
	private SkillTypeService mySkillTypeService;
	

	public SkillTypeService getMySkillTypeService() {
		return mySkillTypeService;
	}

	public void setMySkillTypeService(SkillTypeService mySkillTypeService) {
		this.mySkillTypeService = mySkillTypeService;
	}

	protected String doExecute(ActionForm form, HttpServletRequest request,
			HttpServletResponse response, ActionMapping mapping)
			throws Exception {
		SkillTypeForm myForm = (SkillTypeForm) form;
		//saving skill type
		mySkillTypeService.createSkillType(myForm);
		//load again the skill types
		mySkillTypeService.firstLoadSkillTypeDisplayTag(myForm);
		return "gotoSkillType";
	}

	@Override
	protected String doInit(ActionForm form, HttpServletRequest request,
			HttpServletResponse response, ActionMapping mapping) {
		SkillTypeForm myForm = (SkillTypeForm) form;
		HttpSession session = request.getSession(false);
		if (session.getAttribute("id") == null) {
			return "gotoLogin";
		}
		//first load skill type
		mySkillTypeService.firstLoadSkillTypeDisplayTag(myForm);
		return "gotoSkillType";
		
	}

}
