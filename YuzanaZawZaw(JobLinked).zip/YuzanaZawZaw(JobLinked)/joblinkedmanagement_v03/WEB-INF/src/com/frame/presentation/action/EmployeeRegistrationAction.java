package com.frame.presentation.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

import com.frame.business.service.EmployeeService;
import com.frame.presentation.form.EmployeeForm;

/**
*
* @author Yuzana Zaw Zaw
*/
public class EmployeeRegistrationAction extends BaseAction {
	private EmployeeService myEmployeeService;
	public EmployeeService getMyEmployeeService() {
		return myEmployeeService;
	}


	public void setMyEmployeeService(EmployeeService myEmployeeService) {
		this.myEmployeeService = myEmployeeService;
	}


	@Override
	protected String doExecute(ActionForm form, HttpServletRequest request,
			HttpServletResponse response, ActionMapping mapping)
			throws Exception {
		EmployeeForm myForm = (EmployeeForm) form;
		if (request.getParameter("btnRegisterCancel") != null) {
			return "gotoHome";
		}
		if (request.getParameter("btnSaveCancel") != null) {
			myForm.setFrmRegFormControl(null);
			return "gotoRegister";
		}
		if(isCancelled(request))
		{
			return "gotoHome";
		}
		if (request.getParameter("btnRegister") != null) {
			ActionErrors errors = new ActionErrors();
			myEmployeeService.checkEmail(myForm);
				if (myForm.getFrmEmailError() == null) {
					errors.add("emailError", new ActionMessage(
							"errors.duplicateEmail"));
					saveErrors(request, errors);
				}
						
			return "gotoRegister";
		}
		
		if (request.getParameter("btnSave") != null) {			
			myEmployeeService.saveNewEmployee(myForm);
			return "gotoHome";
						
		}
		return "gotoRegister";
	}

	@Override
	protected String doInit(ActionForm form, HttpServletRequest request,
			HttpServletResponse response, ActionMapping mapping) {
		EmployeeForm myForm = (EmployeeForm) form;
		myEmployeeService.firstLoadRegistration(myForm);
		return "gotoRegister";
	}

}
