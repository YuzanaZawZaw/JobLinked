package com.frame.presentation.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import com.frame.business.service.EmployeeService;
import com.frame.presentation.form.AdminForm;
import com.frame.presentation.form.EmployeeForm;

/**
 * 
 * @author Yuzana Zaw Zaw
 */
public class AdminActivateEmpAccountAction extends BaseAction {
	private EmployeeService myEmployeeService;
	
	public EmployeeService getMyEmployeeService() {
		return myEmployeeService;
	}

	public void setMyEmployeeService(EmployeeService myEmployeeService) {
		this.myEmployeeService = myEmployeeService;
	}

	protected String doExecute(ActionForm form, HttpServletRequest request,
			HttpServletResponse response, ActionMapping mapping)
			throws Exception {
		EmployeeForm myForm=(EmployeeForm) form;
		HttpSession session = request.getSession(false);
		if (session.getAttribute("id") == null) {
			return "gotoLogin";
		}
		AdminForm loginForm = (AdminForm) request.getSession().getAttribute(
				"AdminLoginFormBean");
		return "gotoEmpList";
	}

	@Override
	protected String doInit(ActionForm form, HttpServletRequest request,
			HttpServletResponse response, ActionMapping mapping) {
		//EmployeeForm object
		EmployeeForm myForm=(EmployeeForm) form;
		//getting session
		HttpSession session = request.getSession(false);
		if (session.getAttribute("id") == null) {
			return "gotoLogin";
		}
		//getting Login User form bean
		AdminForm loginForm = (AdminForm) request.getSession().getAttribute(
				"AdminLoginFormBean");
		//calling activateEmpAccount service from EmployeeService
		myEmployeeService.activateEmpAccount(myForm,loginForm);
		return "gotoEmpList";
	}

}
