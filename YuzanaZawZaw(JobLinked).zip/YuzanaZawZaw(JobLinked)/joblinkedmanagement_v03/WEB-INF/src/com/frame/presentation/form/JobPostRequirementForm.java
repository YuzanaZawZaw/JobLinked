package com.frame.presentation.form;


import org.apache.struts.validator.ValidatorForm;

/**
*
* @author Yuzana Zaw Zaw
*/
public class JobPostRequirementForm extends ValidatorForm {
	//for creating job post requirements
	private String frmDescription;
	private String frmJobPostId;
	private String frmJobPostRequirementId;
	
	public String getFrmJobPostRequirementId() {
		return frmJobPostRequirementId;
	}

	public void setFrmJobPostRequirementId(String frmJobPostRequirementId) {
		this.frmJobPostRequirementId = frmJobPostRequirementId;
	}

	public String getFrmJobPostId() {
		return frmJobPostId;
	}

	public void setFrmJobPostId(String frmJobPostId) {
		this.frmJobPostId = frmJobPostId;
	}

	public String getFrmDescription() {
		return frmDescription;
	}

	public void setFrmDescription(String frmDescription) {
		this.frmDescription = frmDescription;
	}
}
