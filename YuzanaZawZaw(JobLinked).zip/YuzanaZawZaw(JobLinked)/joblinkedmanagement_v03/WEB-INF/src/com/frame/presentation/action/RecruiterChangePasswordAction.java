package com.frame.presentation.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import com.frame.business.service.RecruitersService;
import com.frame.presentation.form.RecruiterForm;
/**
*
* @author Yuzana Zaw Zaw
*/
public class RecruiterChangePasswordAction extends BaseAction {
	private RecruitersService myRecruitersService;

	

	public RecruitersService getMyRecruitersService() {
		return myRecruitersService;
	}

	public void setMyRecruitersService(RecruitersService myRecruitersService) {
		this.myRecruitersService = myRecruitersService;
	}

	protected String doExecute(ActionForm form, HttpServletRequest request,
			HttpServletResponse response, ActionMapping mapping)
			throws Exception {
		// TODO Auto-generated method stub
		RecruiterForm myForm = (RecruiterForm) form;
		ActionErrors errors = new ActionErrors();
		HttpSession session = request.getSession(false);
		if (session.getAttribute("id") == null) {
			return "gotoLogin";
		}

		RecruiterForm loginForm = (RecruiterForm) request.getSession().getAttribute(
				"RecFormBean");
		myForm.setLoginUser(loginForm.getLoginUser());
		//check that the the old password is correct
		boolean loginUserFlag = myRecruitersService.checkLoginUser(loginForm
				.getLoginUser().getEmail(), myForm.getFrmChangeOldPassword());
		if (myForm.getFrmChangeOldPassword().equals("")) {
			errors.add("passwordError", new ActionMessage("errors.oldPassword"));
			saveErrors(request, errors);
			return "gotoRecChangePass";
		}
		if (myForm.getFrmChangeNewPassword().equals("")) {
			errors.add("passwordError", new ActionMessage("errors.newPassword"));
			saveErrors(request, errors);
			return "gotoRecChangePass";
		}
		if (myForm.getFrmChangeConfirmPassword().equals("")) {
			errors.add("passwordError", new ActionMessage(
					"errors.confirmPassword"));
			saveErrors(request, errors);
			return "gotoRecChangePass";
		}
		//check that the the old password and new password are the same
		if (loginUserFlag == true) {
			if (myForm.getFrmChangeNewPassword().equals(
					myForm.getFrmChangeConfirmPassword())
					&& !myForm.getFrmChangeNewPassword().equals("")
					&& !myForm.getFrmChangeConfirmPassword().equals("")) {
				myRecruitersService.saveUpdateRecruiterPass(myForm);
				return "gotoRecModule";
			} else {
				errors.add("passwordError", new ActionMessage(
						"errors.matchPassword"));
				saveErrors(request, errors);
				return "gotoRecChangePass";
			}
		} else {
			errors.add("passwordError", new ActionMessage(
					"err.user.old.password.invalid"));
			saveErrors(request, errors);
			return "gotoRecChangePass";
		}
	}

}
