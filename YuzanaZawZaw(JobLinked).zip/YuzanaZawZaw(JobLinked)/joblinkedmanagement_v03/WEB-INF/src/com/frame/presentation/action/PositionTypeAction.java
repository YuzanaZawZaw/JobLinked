package com.frame.presentation.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import com.frame.business.service.PositionTypeService;
import com.frame.presentation.form.PositionTypeForm;

/**
*
* @author Yuzana Zaw Zaw
*/
public class PositionTypeAction extends BaseAction {
	private PositionTypeService myPositionTypeService;


	public PositionTypeService getMyPositionTypeService() {
		return myPositionTypeService;
	}

	public void setMyPositionTypeService(PositionTypeService myPositionTypeService) {
		this.myPositionTypeService = myPositionTypeService;
	}

	protected String doExecute(ActionForm form, HttpServletRequest request,
			HttpServletResponse response, ActionMapping mapping)
			throws Exception {
		PositionTypeForm myForm = (PositionTypeForm) form;
		//create position type
		myPositionTypeService.createPartyGroupPositionType(myForm);
		//load again position types 
		myPositionTypeService.firstLoadPositionTypeDisplayTag(myForm);
		return "gotoPositionType";
	}

	@Override
	protected String doInit(ActionForm form, HttpServletRequest request,
			HttpServletResponse response, ActionMapping mapping) {
		PositionTypeForm myForm = (PositionTypeForm) form;
		HttpSession session = request.getSession(false);
		if (session.getAttribute("id") == null) {
			return "gotoLogin";
		}
		//getting position types
		myPositionTypeService.firstLoadPositionTypeDisplayTag(myForm);
		return "gotoPositionType";
		
	}

}
