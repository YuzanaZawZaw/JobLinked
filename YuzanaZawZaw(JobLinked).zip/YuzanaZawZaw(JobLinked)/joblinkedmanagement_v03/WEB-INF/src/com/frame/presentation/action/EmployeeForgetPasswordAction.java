package com.frame.presentation.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

import com.frame.business.service.EmployeeService;
import com.frame.presentation.form.EmployeeForm;

/**
*
* @author Yuzana Zaw Zaw
*/
public class EmployeeForgetPasswordAction extends BaseAction {
	private EmployeeService myEmployeeService;
	
	
	public EmployeeService getMyEmployeeService() {
		return myEmployeeService;
	}


	public void setMyEmployeeService(EmployeeService myEmployeeService) {
		this.myEmployeeService = myEmployeeService;
	}


	protected String doExecute(ActionForm form, HttpServletRequest request,
			HttpServletResponse response, ActionMapping mapping)
			throws Exception {
		// TODO Auto-generated method stub
	   EmployeeForm myForm=(EmployeeForm)form;
	   ActionErrors errors=new ActionErrors();
	   if(myForm.getFrmForgetPassEmail().equals("")){		
		   errors.add("forgetPassError", new ActionMessage("errors.login.email.required"));
		   saveErrors(request,errors);
		   return "gotoLogin";
	   }
	   if(myForm.getFrmForgetPassSecurityQuest().equals("")){		
		   errors.add("forgetPassError", new ActionMessage("errors.login.securityq.required"));
		   saveErrors(request,errors);
		   return "gotoLogin";
	   }	   	   
	   myEmployeeService.verifySecurityQuestion(myForm);
	   if(myForm.getLoginUser()==null)
	   { 
		   errors.add("forgetPassError", new ActionMessage("errors.forget.password"));
		   saveErrors(request,errors);
		   return "gotoForgetPass";
	   }
	   else
	   {
		   request.getSession(true);
		   request.getSession().setAttribute("id", request.getSession().getId());		   
		   return "gotoEmployeeModule";
	   }
		
	}


}
