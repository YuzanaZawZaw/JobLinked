package com.frame.dao;

import java.util.List;

import com.frame.business.entity.Employee;
import com.frame.business.entity.EmployeePositionFulfillment;
import com.frame.business.entity.EmployeePositionFulfillmentPK;
/**
*
* @author Yuzana Zaw Zaw
*/
public interface EmployeeExpDao {

	List<EmployeePositionFulfillment> getEmployeeExpListAll(Employee emp);

	EmployeePositionFulfillment getCurrentPositionByLoginUser(Employee loginUser);

	void saveEmployeeExperience(EmployeePositionFulfillment empPosition);

	void deleteEmployeeExperience(EmployeePositionFulfillmentPK pk);
	
}
