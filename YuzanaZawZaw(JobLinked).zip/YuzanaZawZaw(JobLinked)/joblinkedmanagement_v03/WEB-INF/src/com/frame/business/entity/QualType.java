package com.frame.business.entity;

import com.frame.business.entity.base.BaseQualType;



public class QualType extends BaseQualType {
	private static final long serialVersionUID = 1L;

/*[CONSTRUCTOR MARKER BEGIN]*/
	public QualType () {
		super();
	}

	/**
	 * Constructor for primary key
	 */
	public QualType (java.lang.Integer id) {
		super(id);
	}

/*[CONSTRUCTOR MARKER END]*/


}