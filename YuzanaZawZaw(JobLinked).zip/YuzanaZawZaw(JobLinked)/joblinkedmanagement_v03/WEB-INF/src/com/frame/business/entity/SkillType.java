package com.frame.business.entity;

import com.frame.business.entity.base.BaseSkillType;



public class SkillType extends BaseSkillType {
	private static final long serialVersionUID = 1L;

/*[CONSTRUCTOR MARKER BEGIN]*/
	public SkillType () {
		super();
	}

	/**
	 * Constructor for primary key
	 */
	public SkillType (java.lang.Integer id) {
		super(id);
	}

/*[CONSTRUCTOR MARKER END]*/


}