package com.frame.business.entity;

import com.frame.business.entity.base.BaseEmployeeSkill;



public class EmployeeSkill extends BaseEmployeeSkill {
	private static final long serialVersionUID = 1L;

/*[CONSTRUCTOR MARKER BEGIN]*/
	public EmployeeSkill () {
		super();
	}

	/**
	 * Constructor for primary key
	 */
	public EmployeeSkill (com.frame.business.entity.EmployeeSkillPK id) {
		super(id);
	}

/*[CONSTRUCTOR MARKER END]*/


}