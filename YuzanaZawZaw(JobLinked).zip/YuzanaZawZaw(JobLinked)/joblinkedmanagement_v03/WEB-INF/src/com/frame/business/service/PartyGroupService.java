package com.frame.business.service;
import java.util.List;

import com.frame.business.entity.PartyGroup;
import com.frame.dao.PartyGroupDao;
import com.frame.presentation.form.PartyGroupForm;

/**
*
* @author Yuzana Zaw Zaw
*/
public class PartyGroupService {
	private PartyGroupDao myPartyGroupDao;


	public PartyGroupDao getMyPartyGroupDao() {
		return myPartyGroupDao;
	}


	public void setMyPartyGroupDao(PartyGroupDao myPartyGroupDao) {
		this.myPartyGroupDao = myPartyGroupDao;
	}


	public void createPartyGroup(PartyGroupForm myForm) 
	{
		PartyGroup partyGroup=new PartyGroup();
		partyGroup.setId(null);
		partyGroup.setGroupNameLocal(myForm.getFrmCompanyName());
		partyGroup.setTotalEmployee(myForm.getFrmTotalEmployee());
		partyGroup.setDescription(myForm.getFrmDescription());
		myPartyGroupDao.savePartyGroup(partyGroup);
		myForm.setFrmCompanyName("");
		myForm.setFrmTotalEmployee("");
		myForm.setFrmDescription("");
	}


	public void firstLoadPartyGroupDisplayTag(PartyGroupForm myForm) {
		List<PartyGroup> l=myPartyGroupDao.getLoadPartyGroupList();
		if(l!=null){
			myForm.setFrmPartyGroupList(l);
		}
	}

	public void deletePartyGroup(PartyGroupForm myForm,int partyGroupId) {
		PartyGroup st=new PartyGroup();
		st.setId(myForm.getPartyGroupId());
		myPartyGroupDao.deletePartyGroup(st);
	}
	
}
