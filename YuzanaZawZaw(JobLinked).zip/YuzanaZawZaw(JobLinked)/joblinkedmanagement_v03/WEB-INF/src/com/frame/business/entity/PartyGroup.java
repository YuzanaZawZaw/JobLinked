package com.frame.business.entity;

import com.frame.business.entity.base.BasePartyGroup;



public class PartyGroup extends BasePartyGroup {
	private static final long serialVersionUID = 1L;

/*[CONSTRUCTOR MARKER BEGIN]*/
	public PartyGroup () {
		super();
	}

	/**
	 * Constructor for primary key
	 */
	public PartyGroup (java.lang.Integer id) {
		super(id);
	}

/*[CONSTRUCTOR MARKER END]*/


}