package com.frame.business.service;
import java.util.List;

import com.frame.business.entity.QualType;
import com.frame.dao.QualTypeDao;
import com.frame.presentation.form.JobPostQualForm;
import com.frame.presentation.form.QualTypeForm;
import com.frame.presentation.form.RecruiterForm;

/**
*
* @author Yuzana Zaw Zaw
*/
public class QualTypeService {
	private QualTypeDao myQualTypeDao;


	public QualTypeDao getMyQualTypeDao() {
		return myQualTypeDao;
	}


	public void setMyQualTypeDao(QualTypeDao myQualTypeDao) {
		this.myQualTypeDao = myQualTypeDao;
	}


	public void createQualType(QualTypeForm myForm) 
	{
		QualType qualType=new QualType();
		qualType.setId(null);
		qualType.setDescription(myForm.getFrmQualTypeName());
		myQualTypeDao.saveQualType(qualType);
		myForm.setFrmQualTypeName("");
	}


	public void firstLoadQualTypeDisplayTag(QualTypeForm myForm) {
		List<QualType> l=myQualTypeDao.getLoadQualTypeList();
		if(l!=null){
			myForm.setFrmQualTypeList(l);
		}
		
	}

	public void deleteQualType(QualTypeForm myForm,int qualTypeId) {
		QualType st=new QualType();
		st.setId(myForm.getQualTypeId());
		myQualTypeDao.deleteQualType(st);
	}


	public void firstLoadQualTypeDisplayTag(JobPostQualForm myForm) {
		List<QualType> l=myQualTypeDao.getLoadQualTypeList();
		if(l!=null){
			myForm.setQualList(l);
		}
	}
	
}
