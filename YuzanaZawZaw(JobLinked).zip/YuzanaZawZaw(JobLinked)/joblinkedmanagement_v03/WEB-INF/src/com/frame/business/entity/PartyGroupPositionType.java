package com.frame.business.entity;

import com.frame.business.entity.base.BasePartyGroupPositionType;



public class PartyGroupPositionType extends BasePartyGroupPositionType {
	private static final long serialVersionUID = 1L;

/*[CONSTRUCTOR MARKER BEGIN]*/
	public PartyGroupPositionType () {
		super();
	}

	/**
	 * Constructor for primary key
	 */
	public PartyGroupPositionType (java.lang.Integer id) {
		super(id);
	}

/*[CONSTRUCTOR MARKER END]*/


}